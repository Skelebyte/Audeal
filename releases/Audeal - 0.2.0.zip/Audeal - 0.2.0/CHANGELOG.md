0.2.0
Added `adl` namespace for Audeal classes.
